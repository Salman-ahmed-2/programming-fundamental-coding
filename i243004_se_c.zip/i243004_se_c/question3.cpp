//salman ahmed 
// se c 
// i243004

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()

{


int z;
while (true){
flag:
cout<<"select a formula "<<endl;
cout<<" 1. quadratic equation "<<endl;
cout<<" 2. body mass index  "<<endl;
cout<<" 3. simple interest "<<endl;
cout<<" 4. exit"<<endl;
cin>>z;
if (z<1 && z>4)
goto flag;


if ( z==1)
{
float a,b,c;
cout<<" give value of a , b and c ";
cin>>a>>b>>c;
float v;
v=(((b*2)-(4*a*c*b*b))-((8*a*b)-(4*a*c)));
if (v>=0)
{cout<<"two roots";
cout<<v<<endl;
cout<<-v<<endl;}
else {
cout<<" it has complex roots"<<endl;}


float x1,x2;
float p;
p=sqrt((b*b)-(4*a*c));
x1=(((-b)+p)/2*a);
x2=(((-b)-p)/2*a);

cout<<x1<<endl<<x2<<endl;}


else if (z==2)
{
float bmi,h,w;
f1:
cout<<" give value of weight, hight "<<endl;
cin>>h>>w;
if (h<0 || w<0){
cout<<" try again";
goto f1;}

bmi=w/h*h;

cout<<setprecision(1)<<"bmi is "<<bmi;}

else if (z==3)
{ float si,p,r,t;

f2:
cout<<" give value of p, r,t "<<endl;
cin>>p>>r>>t;
if (p<0 || r<0 || t<0){
cout<<" try again";
goto f2;}

si =(p*r*t)/100;
cout<<" si " <<si;}
else if (z==4)
{break;}
else{ cout<<" try again"; }}}




