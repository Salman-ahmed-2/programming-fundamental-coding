//salman ahmed 
// se c 
// i243004

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
const int idd[14];
void initiaizeParking(int* lot[]){

*lot[14]={-1};

}

void displayParking( int* lot[]){
for(int i=0;i<14;i++)
{
if (*lot[i]==-1)
cout<<i<<" " <<" free";

else if (*lot[i]==1)
cout<<i<<" " <<" car";
else if (*lot[i]==2)
cout<<i<<" " <<" bus";
else 
cout<<i<<" " <<" truck";}}

void parkVehicle(int *lot[] , int vehicleType , int id){


if (vehicleType ==1){
int p=0;

for (int i=0;*lot[i]==-1;i++)
{p++;}
*lot[p]==1;
idd[p]==id;}

else if (vehicleType ==2){
int p=0;

for (int i=0;*lot[i]==-1;i++)
{p++;}
*lot[p]==2;
idd[p]==id;}

else {
int p=0;

for (int i=0;*lot[i]==-1;i++)
{p++;}
*lot[p]==3;
idd[p]==id;}}
void removeVehicle(int *lot[] ,int *idd[]){}


int main()

{
int  loot[14];
int id [14];
int idd[14];
while (true){
int op;
flag:
cout<<"select option"<<endl;
cout<<" 1. park "<<endl;
cout<<" 2. remove  "<<endl;
cout<<" 3. disply "<<endl;
cout<<" 4. exit"<<endl;
cin>>op;

if (op<1 && op>4)
goto flag;
initiaizeParking(loot);

if (op==1){
int vehicleType;
flag1:
cout<<"select option"<<endl;
cout<<" 1. bus "<<endl;
cout<<" 2. car  "<<endl;
cout<<" 3. truck "<<endl;
cin>>vehicleType;


if (vehicleType<1 && vehicleType>3)
goto flag1;
int id;
cout<<"id";
cin>>id;
parkVehicle(loot,&vehicleType,&id);}
else if (op==2){

removeVehicle(loot,idd);
}

else if (op==3){}
else 
break;}}
