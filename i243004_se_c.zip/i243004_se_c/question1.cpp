//salman ahmed 
// se c 
// i243004

#include <iostream>
using namespace std;
int main()

{

int n;
flag:
cout<<"enter a number :";
cin>>n;
if(n<=19 && n>=3 && n%2!=0)
cout<<"correct number";

else 
{cout<<"wrong number try again";
goto flag;}
int k=n/2;
for (int i=0;i<n;i++)
{

while(k>0){
cout<<" ";
k--;}
for (int j=0;j<i;j++)
{ 



if(j==0 || j==i-1 ||(j==(n/2)+1 && i%2!=0))
cout<<"1 ";
else
cout<<"0 ";}
cout<<endl;}


for (int i=n;i>0;i--)
{for (int j=0;j<i;j++)
{
if(j==0|| j==i-1|| (j==(n/2)+1 && i%2!=0))
cout<<"1 ";
else
cout<<"0 ";}
cout<<endl;}}
